<template>

</template>
<script> // @code
export default {
    name: 'AvaliableServices',
    data () {
        return {
        msg: 'Welcome to Your Vue.js App'
        }
    }
}
</script>